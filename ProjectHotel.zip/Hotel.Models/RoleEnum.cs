﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hotel.Models
{
    public enum RoleEnum
    {
        Admin = 1,
        Manager = 2,
        Guest = 3
    }
}
